import java.net.Socket;
public class PortScanner {

	public static void main(String[] args) {
        String targetHost = "127.0.0.1"; // Replace with the target IP address or hostname
        int startPort = 0; // Specify the start port
        int endPort = 1023; // Specify the end port

        System.out.println("Scanning ports on " + targetHost + "...");

        for (int port = startPort; port <= endPort; port++) {
            if (isPortOpen(targetHost, port)) {
                System.out.println("Port " + port + " is open");
            } else {
                System.out.println("Port " + port + " is closed");
            }
        }
    }

    private static boolean isPortOpen(String host, int port) {
        try (Socket socket = new Socket(host, port)) {
            // If the socket is successfully created, the port is open
            return true;
        } catch (Exception e) {
            // If an exception occurs, the port is likely closed
            return false;
        }
    }
}




